
package hust.soict.dsai.aims.media;

import hust.soict.dsai.aims.exception.PlayerException;

public class DigitalVideoDiscTienLC extends DiscTienLC implements PlayableTienLC {
    @Override
    public void play(){
        System.out.println("Playing DVD: " + this.getTitle());
        System.out.println("DVD length: " + this.getLength());
    }
    //Constructor 
    public DigitalVideoDiscTienLC(String title) {
        super(title);
    }    
    public DigitalVideoDiscTienLC(String title, String category, float cost) {
        super(title, category, cost);
    }
    public DigitalVideoDiscTienLC(String title, String category, String director, float cost) {
        super(title, category, director, cost);
    }
    public DigitalVideoDiscTienLC(String title, String category, String director, int length, float cost) {
        super(title, category, director, length, cost);
    }
    
    @Override
    public String toString() {
        return this.getId() + " - DVD: " + this.getTitle() +
                " - Category: " + this.getCategory() +
                " - Director: " + this.getDirector() +
                " - DVD length: " + this.getLength() +
                " - Cost: " + this.getCost() + "$";
    }

    public String playGUI() throws PlayerException {
        if (this.getLength() > 0) {
                return "Playing DVD: " + this.getTitle() + "\n" + 
                    "DVD length: " + formatDuration(this.getLength());
            } else {
                throw new PlayerException("ERROR: DVD length is non-positive!");
            }
    }
}