
package hust.soict.dsai.aims.media;

public interface PlayableTienLC {
    public void play();
}


