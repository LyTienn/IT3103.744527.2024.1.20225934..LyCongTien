
//Example1: HelloWorld.java
//Text-printing program
package Lab01;
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Ly Cong Tien - 20225934");
        System.out.println("Xin chao \n cac ban!"); //lenh in ra man hinh
        System.out.println("Hello \t world!");
    } //end of method main
}



