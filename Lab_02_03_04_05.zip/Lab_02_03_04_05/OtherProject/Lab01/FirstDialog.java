
//Example2: FirstDialog.java
package Lab01; // Tổ chức các lớp, giao diện,...(class, interface,...)
import javax.swing.JOptionPane; // Nhập lớp JOptionPane từ thư viện javax.swing
public class FirstDialog {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"Ly Cong Tien - 20225934 - Hello world! How are you?");// In ra thông báo trên Dialog
        System.exit(0);
    }
}


