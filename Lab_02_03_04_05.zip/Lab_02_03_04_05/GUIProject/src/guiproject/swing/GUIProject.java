
package guiproject.swing;


public class GUIProject {

    public static void main(String[] args) {
    
    }
    
}
